import { Component } from '@angular/core';

@Component({
selector: 'app-invoice',
templateUrl: './invoice.component.html',
styleUrls: ['./invoice.component.less']
})
export class InvoiceComponent { }
