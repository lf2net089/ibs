import { Component } from '@angular/core';

@Component({
selector: 'app-permissions',
templateUrl: './permissions.component.html',
styleUrls: ['./permissions.component.less']
})
export class PermissionsComponent { }
