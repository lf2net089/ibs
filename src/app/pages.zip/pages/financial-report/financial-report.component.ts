import { Component } from '@angular/core';

@Component({
selector: 'app-financial-report',
templateUrl: './financial-report.component.html',
styleUrls: ['./financial-report.component.less']
})
export class FinancialReportComponent { }
