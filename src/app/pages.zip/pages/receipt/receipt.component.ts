import { Component } from '@angular/core';

@Component({
selector: 'app-receipt',
templateUrl: './receipt.component.html',
styleUrls: ['./receipt.component.less']
})
export class ReceiptComponent { }
