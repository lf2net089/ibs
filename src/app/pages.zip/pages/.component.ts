import { Component } from '@angular/core';

@Component({
selector: 'app-',
templateUrl: './.component.html',
styleUrls: ['./.component.less']
});
export class ~~1Component { }
