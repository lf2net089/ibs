import { Component } from '@angular/core';

@Component({
selector: 'app-query',
templateUrl: './query.component.html',
styleUrls: ['./query.component.less']
})
export class QueryComponent { }
