import { Component } from '@angular/core';

@Component({
selector: 'app-data-maintenance',
templateUrl: './data-maintenance.component.html',
styleUrls: ['./data-maintenance.component.less']
})
export class DataMaintenanceComponent { }
