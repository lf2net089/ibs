import { Component } from '@angular/core';

@Component({
selector: 'app-system-maintenance',
templateUrl: './system-maintenance.component.html',
styleUrls: ['./system-maintenance.component.less']
})
export class SystemMaintenanceComponent { }
